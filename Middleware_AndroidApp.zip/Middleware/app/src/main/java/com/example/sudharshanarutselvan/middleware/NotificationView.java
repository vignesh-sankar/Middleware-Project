package com.example.sudharshanarutselvan.middleware;

import android.support.v7.app.AppCompatActivity;

/**
 * Created by SudharshanArutselvan on 6/8/2017.
 */

public class NotificationView  extends AppCompatActivity {


}
